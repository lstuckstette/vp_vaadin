package com.veraplan.teacherWishlist;

import com.vaadin.ui.renderers.TextRenderer;

public class TimeSlotRenderer extends TextRenderer {

	
	

}

package com.veraplan.teacherWishlist;

public class TimeSlot {

	private int weekday;
	private int timeSlotNumber;
	private String comment;

	public TimeSlot(int weekday, int timeSlotNumber) {

		this.weekday = weekday;
		this.timeSlotNumber = timeSlotNumber;
		this.comment = "comment";

	}
	

	public int getWeekday() {
		return weekday;
	}


	public int getTimeSlotNumber() {
		return timeSlotNumber;
	}


	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	

}

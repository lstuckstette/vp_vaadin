package com.veraplan.teacherWishlist;

public class TimeSlotRowContainer {

	private TimeSlotTime startTime;
	private TimeSlotTime endTime;
	private String monday, tuesday, wednesday, thursday, friday;

	public TimeSlotRowContainer(int timeSlotNumber) {

		this.startTime = StaticSchoolData.getTimeSlotStartTime(timeSlotNumber);
		this.endTime = StaticSchoolData.getTimeSlotEndTime(timeSlotNumber);
		/*
		 * this.monday = new TimeSlot(1,timeSlotNumber); this.tuesday = new
		 * TimeSlot(2,timeSlotNumber); this.wednesday = new
		 * TimeSlot(3,timeSlotNumber); this.tuesday = new
		 * TimeSlot(4,timeSlotNumber); this.friday = new
		 * TimeSlot(5,timeSlotNumber);
		 */
	}

	public String getTimeString() {

		// format TimeStrings with leading zero's:

		String startHour = startTime.getHours() < 10 ? "0" + startTime.getHours() : "" + startTime.getHours();
		String startMinute = startTime.getMinutes() < 10 ? "0" + startTime.getMinutes() : "" + startTime.getMinutes();

		String endHour = endTime.getHours() < 10 ? "0" + endTime.getHours() : "" + endTime.getHours();
		String endMinute = endTime.getMinutes() < 10 ? "0" + endTime.getMinutes() : "" + endTime.getMinutes();

		return "" + startHour + ":" + startMinute + " - " + endHour + ":" + endMinute;
	}

	public String getMonday() {
		return monday;
	}

	public String getTuesday() {
		return tuesday;
	}

	public String getWednesday() {
		return wednesday;
	}

	public String getThursday() {
		return thursday;
	}

	public String getFriday() {
		return friday;
	}

}
